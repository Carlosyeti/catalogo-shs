# SHS Tools — Herramientas Internas

Herramientas de gestión interna para Surtidora de Higiénicos y Servicios.

## Archivos

- `index.html` — Panel de acceso
- `master-cobranza.html` — Cobranza, factoraje, flujo
- `master-financiero.html` — Estados financieros
- `gastos-auxiliar.html` — Captura de gastos

## Deploy

Conectado a Vercel. Cada push a `main` actualiza automáticamente.
